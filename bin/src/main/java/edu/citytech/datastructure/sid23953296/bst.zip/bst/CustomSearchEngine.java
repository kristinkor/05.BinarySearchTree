package edu.citytech.datastructure.bst;

import java.util.function.Consumer;

import static edu.citytech.datastructure.bst.TreeHelper.*;

public class CustomSearchEngine<T extends Comparable<T>> extends AbstractSearchEngine<T> {

    private T binarySearch(Node<T> node, T value, Consumer<T> consumer) {
        consumer.accept(node.value);

        if (isEqual(node.value, value)) {
            return node.value;
        } else if (isLessThan(value, node.value)) {
            binarySearch(node.leftChild, value, consumer);

        } else if (isGreaterThan(value, node.value)) {
            binarySearch(node.rightChild, value, consumer);
        }

        return null;
    }

    @Override
    public T find(Node<T> node, T value, Consumer<T> consumer) {
        return this.binarySearch(node, value, consumer);
    }

    @Override
    public T min(Node<T> node) {
        return this.findMin(node.leftChild);
    }

    private T findMin(Node<T> node) {
        if (node.leftChild == null)
            return node.value;
        return findMin(node.leftChild);
    }

    @Override
    public T max(Node<T> node) {
        return this.findMax(node.rightChild);
    }


    private T findMax(Node<T> node) {
        if (node.rightChild == null)
            return node.value;
        return findMax(node.rightChild);

    }


}
