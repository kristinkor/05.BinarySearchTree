package edu.citytech.datastructure.bst;


import java.util.function.Consumer;

// function of this abstract method is to be inherited
public abstract class AbstractSearchEngine<T extends Comparable<T>> {
    public abstract T find(Node<T> root, T value, Consumer<T> consumer);

    public abstract T min(Node<T> node);

    public abstract T max(Node<T> node);
}
