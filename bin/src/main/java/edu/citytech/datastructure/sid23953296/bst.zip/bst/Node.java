package edu.citytech.datastructure.bst;

class Node<T extends Comparable<T>> {
    T value;
    Node<T> leftChild;
    Node<T> rightChild;

    public Node(T value) {
        this.value = value;
    }

    public String toString() {
        return "Node " + this.value;
    }
}
