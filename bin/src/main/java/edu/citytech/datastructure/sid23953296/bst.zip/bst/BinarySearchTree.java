package edu.citytech.datastructure.bst;

import java.util.Arrays;
import java.util.function.Consumer;

import static edu.citytech.datastructure.bst.TreeHelper.*;

public class BinarySearchTree<T extends Comparable<T>> {
    private Node<T> root;
    private AbstractSearchEngine<T> findEngine = null;

    public BinarySearchTree() {
        this.findEngine = new DefaultSearch<T>();
    }

    public BinarySearchTree(AbstractSearchEngine findEngine) {
        this.findEngine = findEngine;
    }

    public void batchInserts(T... values) {
        Arrays.stream(values).forEach(this::insert);
    }

    public void insert(T value) {
        var node = new Node(value);
        if (TreeHelper.isEmpty(root)) {
            root = node;
            return;
        }

        var current = root;
        while (true) {
            if (TreeHelper.isLessThan(value, current.value)) {
                if (TreeHelper.isEmpty(current.leftChild)) {
                    current.leftChild = node;
                    break;
                }
                current = current.leftChild;
            } else if (TreeHelper.isGreaterThan(value, current.value)) {
                if (TreeHelper.isEmpty(current.rightChild)) {
                    current.rightChild = node;
                    break;
                }
                current = current.rightChild;
            } else {
                throw new RuntimeException("duplicate data entered, Invalid see data " + value);
            }
        }
    }

    public T find(T value) {
        return this.find(value, e -> {
        });
    }

    // recursive to do both
    public T find(T value, Consumer<T> consumer) {
        return this.findEngine.find(root, value, consumer);
    }

    public T min() {
        return this.findEngine.min(root);
    }

    public T max() {
        return this.findEngine.max(root);
    }
}
